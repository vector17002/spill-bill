// signup.js

// Form validation
const form = document.querySelector('form');

form.addEventListener('submit', function (e) {
    e.preventDefault();

    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('pass').value.trim();
    const confirmPassword = document.getElementById('re-pass').value.trim();
    const email = document.getElementById('mail').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const aadhaar = document.getElementById('aadhaar').value.trim();

    // Username validation
    const usernameRegex = /^[A-Za-z]{6,}$/;
    if (!username || !usernameRegex.test(username)) {
        alert('Username must be at least 6 characters long and contain only letters.');
        return;
    }

    // Password validation
    const passwordRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    if (!password || !passwordRegex.test(password)) {
        alert('Password must be at least 8 characters, with 1 uppercase letter, 1 number, and 1 special character.');
        return;
    }

    // Confirm password validation
    if (!confirmPassword || confirmPassword !== password) {
        alert('Passwords do not match.');
        return;
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email || !emailRegex.test(email)) {
        alert('Please enter a valid email address.');
        return;
    }

    // Phone number validation
    const phoneRegex = /^\d{10}$/;
    if (!phone || !phoneRegex.test(phone)) {
        alert('Phone number must be exactly 10 digits and contain only numbers.');
        return;
    }

    // Aadhaar number validation (basic check for not null)
    if (!aadhaar) {
        alert('Aadhaar number cannot be empty.');
        return;
    }

    alert('Registration successful!');
    form.submit();
});
