// Common validation functions
function showError(element, message) {
    element.textContent = message;
    element.style.display = 'block';
}

function hideError(element) {
    element.textContent = '';
    element.style.display = 'none';
}

// Login form validation
document.getElementById('loginForm')?.addEventListener('submit', function(e) {
    e.preventDefault();
    const username = document.getElementById('username');
    const password = document.getElementById('password');
    const usernameError = document.getElementById('usernameError');
    const passwordError = document.getElementById('passwordError');
    
    let isValid = true;
    
    // Validate username
    if (!username.value.trim()) {
        showError(usernameError, 'Username is required');
        isValid = false;
    } else {
        hideError(usernameError);
    }
    
    // Validate password
    if (!password.value.trim()) {
        showError(passwordError, 'Password is required');
        isValid = false;
    } else {
        hideError(passwordError);
    }
    
    if (isValid) {
        // Submit form or redirect
        alert('Login successful!');
        window.location.href = 'index.html';
    }
});

// Registration form validation
document.getElementById('registerForm')?.addEventListener('submit', function(e) {
    e.preventDefault();
    const username = document.getElementById('username');
    const password = document.getElementById('password');
    const confirmPassword = document.getElementById('confirmPassword');
    const email = document.getElementById('email');
    const mobile = document.getElementById('mobile');
    const aadhaar = document.getElementById('aadhaar');
    
    const usernameError = document.getElementById('usernameError');
    const passwordError = document.getElementById('passwordError');
    const confirmPasswordError = document.getElementById('confirmPasswordError');
    const emailError = document.getElementById('emailError');
    const mobileError = document.getElementById('mobileError');
    const aadhaarError = document.getElementById('aadhaarError');
    
    let isValid = true;
    
    // Validate username
    const usernameRegex = /^[a-zA-Z0-9]{6,}$/;
    if (!username.value.trim()) {
        showError(usernameError, 'Username is required');
        isValid = false;
    } else if (!usernameRegex.test(username.value)) {
        showError(usernameError, 'Must be 6+ letters, no numbers/special chars');
        isValid = false;
    } else {
        hideError(usernameError);
    }
    
    // Validate password
    const passwordRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    if (!password.value.trim()) {
        showError(passwordError, 'Password is required');
        isValid = false;
    } else if (!passwordRegex.test(password.value)) {
        showError(passwordError, 'Must be 8+ chars with 1 special, 1 number, 1 uppercase');
        isValid = false;
    } else {
        hideError(passwordError);
    }
    
    // Validate confirm password
    if (confirmPassword.value !== password.value) {
        showError(confirmPasswordError, 'Passwords do not match');
        isValid = false;
    } else {
        hideError(confirmPasswordError);
    }
    
    // Validate email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email.value.trim()) {
        showError(emailError, 'Email is required');
        isValid = false;
    } else if (!emailRegex.test(email.value)) {
        showError(emailError, 'Invalid email format');
        isValid = false;
    } else {
        hideError(emailError);
    }
    
    // Validate mobile number
    const mobileRegex = /^\d{10}$/;
    if (!mobile.value.trim()) {
        showError(mobileError, 'Mobile number is required');
        isValid = false;
    } else if (!mobileRegex.test(mobile.value)) {
        showError(mobileError, 'Must be 10 digits, numbers only');
        isValid = false;
    } else {
        hideError(mobileError);
    }
    
    // Validate Aadhaar number
    if (!aadhaar.value.trim()) {
        showError(aadhaarError, 'Aadhaar number is required');
        isValid = false;
    } else {
        hideError(aadhaarError);
    }
    
    if (isValid) {
        // Submit form or redirect
        alert('Registration successful!');
        window.location.href = 'login.html';
    }
});
